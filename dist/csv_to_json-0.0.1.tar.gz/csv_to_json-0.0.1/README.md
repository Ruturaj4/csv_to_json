Python package converts csv to json

Usage: package inputfile
